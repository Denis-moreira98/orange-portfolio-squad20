package br.com.orangeportifolio.squad20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrangePortifolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrangePortifolioApplication.class, args);
	}

}
