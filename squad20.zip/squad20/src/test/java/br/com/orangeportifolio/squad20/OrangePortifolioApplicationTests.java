package br.com.orangeportifolio.squad20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrangePortifolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
